/// 通用主题状态容器。
/// Theme 是泛型，由业务层自行定义；基础设施不会知道它是 Colors、Typography 还是完整 Design System。
@MainActor
public final class ThemeStore<Theme> {
    private(set) public var current: Theme

    private var continuations: [UUID: AsyncStream<Theme>.Continuation] = [:]

    public init(initial: Theme) {
        current = initial
    }

    public func set(_ theme: Theme) {
        current = theme
        continuations.values.forEach { $0.yield(theme) }
    }

    public func updates() -> AsyncStream<Theme> {
        let id = UUID()
        let (stream, continuation) = AsyncStream.makeStream(of: Theme.self)
        continuations[id] = continuation
        continuation.yield(current)
        continuation.onTermination = { _ in
            Task { @MainActor [weak self] in
                self?.continuations.removeValue(forKey: id)
            }
        }
        return stream
    }
}

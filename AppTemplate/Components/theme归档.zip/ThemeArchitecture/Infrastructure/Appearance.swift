import UIKit

/// 用户对显示外观的选择。它只描述 Light / Dark，不包含任何业务颜色。
public enum AppearanceMode: String, Codable, CaseIterable {
    case system
    case light
    case dark
}

/// UIKit 最终生效的外观。
public enum Appearance: Equatable {
    case light
    case dark

    public var isDark: Bool { self == .dark }

    public var statusBarStyle: UIStatusBarStyle {
        isDark ? .lightContent : .darkContent
    }
}

/// 主题基础设施向业务暴露的最小上下文。
/// 注意：这里故意不包含 ColorTheme / ThemeColors / UIColor。
public struct AppearanceContext: Equatable {
    public let mode: AppearanceMode
    public let appearance: Appearance

    public init(mode: AppearanceMode, appearance: Appearance) {
        self.mode = mode
        self.appearance = appearance
    }
}

@MainActor
public final class AppearanceService {
    public static let shared = AppearanceService()

    private weak var window: UIWindow?
    private(set) public var mode: AppearanceMode = .system
    private(set) public var current: AppearanceContext

    private var continuations: [UUID: AsyncStream<AppearanceContext>.Continuation] = [:]

    private init() {
        current = AppearanceContext(mode: .system, appearance: Self.resolve(mode: .system, traits: UITraitCollection.current))
    }

    public func attach(to window: UIWindow, mode: AppearanceMode) {
        self.window = window
        self.mode = mode
        applyInterfaceStyle()
        refresh(using: window.traitCollection, force: true)
    }

    public func setMode(_ mode: AppearanceMode) {
        guard self.mode != mode else { return }
        self.mode = mode
        applyInterfaceStyle()
        refresh(using: window?.traitCollection ?? UITraitCollection.current, force: true)
    }

    /// Scene 的系统外观发生变化时调用。非 .system 模式会忽略该变化。
    public func systemAppearanceDidChange(_ traits: UITraitCollection) {
        guard mode == .system else { return }
        refresh(using: traits)
    }

    /// 每个订阅者先收到当前快照，随后收到变化。
    public func updates() -> AsyncStream<AppearanceContext> {
        let id = UUID()
        let (stream, continuation) = AsyncStream.makeStream(of: AppearanceContext.self)
        continuations[id] = continuation
        continuation.yield(current)
        continuation.onTermination = { _ in
            Task { @MainActor [weak self] in
                self?.continuations.removeValue(forKey: id)
            }
        }
        return stream
    }

    private func refresh(using traits: UITraitCollection, force: Bool = false) {
        let resolved = Self.resolve(mode: mode, traits: traits)
        guard force || resolved != current.appearance else { return }

        current = AppearanceContext(mode: mode, appearance: resolved)
        continuations.values.forEach { $0.yield(current) }
    }

    private func applyInterfaceStyle() {
        switch mode {
        case .system:
            window?.overrideUserInterfaceStyle = .unspecified
        case .light:
            window?.overrideUserInterfaceStyle = .light
        case .dark:
            window?.overrideUserInterfaceStyle = .dark
        }
    }

    private static func resolve(mode: AppearanceMode, traits: UITraitCollection) -> Appearance {
        switch mode {
        case .system:
            return traits.userInterfaceStyle == .dark ? .dark : .light
        case .light:
            return .light
        case .dark:
            return .dark
        }
    }
}

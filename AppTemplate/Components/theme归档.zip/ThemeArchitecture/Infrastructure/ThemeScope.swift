import UIKit

/// 一个页面 / 模块是否参与业务 Theme，由业务主动选择，而不是由全局 ViewController 默认开启。
@MainActor
public protocol ThemeScope: AnyObject {
    associatedtype Theme

    var themeStore: ThemeStore<Theme> { get }
    func applyTheme(_ theme: Theme)
}

/// UIViewController 的通用主题订阅宿主。
/// 只有继承这个类的页面才会自动订阅业务 Theme。
@MainActor
open class ThemedViewController<Theme>: UIViewController {
    public let themeStore: ThemeStore<Theme>
    private var themeTask: Task<Void, Never>?

    public init(themeStore: ThemeStore<Theme>) {
        self.themeStore = themeStore
        super.init(nibName: nil, bundle: nil)
    }

    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    open override func viewDidLoad() {
        super.viewDidLoad()

        themeTask = Task { @MainActor [weak self] in
            guard let self else { return }
            for await theme in self.themeStore.updates() {
                self.applyTheme(theme)
            }
        }
    }

    open func applyTheme(_ theme: Theme) {
        // 子类实现。基础设施不定义任何业务颜色字段。
    }

    deinit {
        themeTask?.cancel()
    }
}

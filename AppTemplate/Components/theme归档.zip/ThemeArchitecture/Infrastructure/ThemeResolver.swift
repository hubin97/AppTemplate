/// 根据基础 AppearanceContext 解析业务 Theme。
/// Resolver 属于业务层实现，基础设施只定义协议。
public protocol ThemeResolver {
    associatedtype Theme

    func resolve(from context: AppearanceContext) -> Theme
}

@MainActor
public final class ResolvedThemeStore<Resolver: ThemeResolver> {
    public typealias Theme = Resolver.Theme

    private let resolver: Resolver
    private let appearanceService: AppearanceService
    public let store: ThemeStore<Theme>
    private var task: Task<Void, Never>?

    public init(resolver: Resolver, appearanceService: AppearanceService = .shared) {
        self.resolver = resolver
        self.appearanceService = appearanceService
        self.store = ThemeStore(initial: resolver.resolve(from: appearanceService.current))

        task = Task { @MainActor [weak self] in
            guard let self else { return }
            for await context in appearanceService.updates() {
                self.store.set(resolver.resolve(from: context))
            }
        }
    }

    deinit {
        task?.cancel()
    }
}

import UIKit

/// 示例 1：项目只需要 Dark Mode，不需要任何业务 Color Theme。
final class LegacySafeViewController: ViewController {

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)

        guard traitCollection.hasDifferentColorAppearance(comparedTo: previousTraitCollection) else {
            return
        }

        // 项目可以直接使用 UIKit dynamic colors：
        // view.backgroundColor = .systemBackground
        // titleLabel.textColor = .label
        // detailLabel.textColor = .secondaryLabel
    }
}

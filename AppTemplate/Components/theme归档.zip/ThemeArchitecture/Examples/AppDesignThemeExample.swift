import UIKit

// MARK: - Business Design System

/// 业务层自己定义颜色语义。基础设施完全不知道这些字段。
struct AppColors {
    let background: UIColor
    let surface: UIColor
    let textPrimary: UIColor
    let textSecondary: UIColor
    let accent: UIColor
    let tabNormal: UIColor
    let tabSelected: UIColor
}

struct AppDesignTheme {
    let colors: AppColors
}

/// 品牌主题也是业务层概念。
enum AppColorTheme {
    case blue
    case green
    case purple
}

struct AppThemeResolver: ThemeResolver {
    let colorTheme: AppColorTheme

    func resolve(from context: AppearanceContext) -> AppDesignTheme {
        let dark = context.appearance.isDark

        let accent: UIColor
        switch colorTheme {
        case .blue:
            accent = dark ? UIColor(hexStr: "#64B5F6") : UIColor(hexStr: "#1976D2")
        case .green:
            accent = dark ? UIColor(hexStr: "#81C784") : UIColor(hexStr: "#388E3C")
        case .purple:
            accent = dark ? UIColor(hexStr: "#BA68C8") : UIColor(hexStr: "#7B1FA2")
        }

        let colors = AppColors(
            background: dark ? .black : .white,
            surface: dark ? UIColor(white: 0.08, alpha: 1) : UIColor(white: 0.96, alpha: 1),
            textPrimary: dark ? .white : .black,
            textSecondary: dark ? .lightGray : .darkGray,
            accent: accent,
            tabNormal: .lightGray,
            tabSelected: accent
        )

        return AppDesignTheme(colors: colors)
    }
}

/// 只在需要业务 Theme 的模块使用这个基类。
final class HomeViewController: ThemedViewController<AppDesignTheme> {
    let titleLabel = UILabel()

    override func applyTheme(_ theme: AppDesignTheme) {
        view.backgroundColor = theme.colors.background
        titleLabel.textColor = theme.colors.textPrimary
    }
}

// 示例初始化：
// let resolver = AppThemeResolver(colorTheme: .blue)
// let appTheme = ResolvedThemeStore(resolver: resolver)
// let vc = HomeViewController(themeStore: appTheme.store)

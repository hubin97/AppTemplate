# Theme Architecture

这版方案针对当前项目讨论的四个边界重新设计：

1. ViewController 是全局基类，但只有指定模块需要 Theme 时才参与。
2. Dark Mode / Appearance 与业务 Color Theme 解耦。
3. `ThemeColors` 不再属于通用基础设施，由业务层自由定义语义和结构。
4. 业务 Theme 不限制为颜色，也可以扩展成完整 Design System。

## 1. 核心原则

### Appearance 是基础能力

`AppearanceService` 只负责：

- system / light / dark 的选择
- UIKit `overrideUserInterfaceStyle`
- 当前最终 Light / Dark 的解析
- Appearance 变化广播

它不包含任何业务 `UIColor`，也不知道 `ColorTheme`。

### Theme 是业务能力

业务自己定义：

```swift
struct AppColors { ... }
struct AppDesignTheme {
    let colors: AppColors
    // let typography: AppTypography
    // let spacing: AppSpacing
}
```

基础设施通过 `ThemeStore<Theme>` 保存和广播泛型 Theme。

### Resolver 负责组合

```text
AppearanceContext
       ↓
 Business ThemeResolver
       ↓
AppDesignTheme
```

这样 Light / Dark 只是输入条件，而不是把颜色字段硬编码在基础设施里。

## 2. Scope：主题默认关闭

不要把主题订阅放进全局 `ViewController`。

```text
ViewController                 ← 所有模块
    │
    ├── LegacyModule            ← 不参与 Theme
    │
    └── ThemedViewController    ← 明确 opt-in
             │
             ├── Home
             ├── Profile
             └── Settings
```

因此“新增 Dark Mode 但只开放部分模块”时，边界天然清晰。

## 3. 纯 Dark Mode 项目

项目只需要 Dark Mode 时，优先使用 UIKit dynamic colors：

```swift
view.backgroundColor = .systemBackground
titleLabel.textColor = .label
detailLabel.textColor = .secondaryLabel
```

需要监听特殊 UI 时，使用 `traitCollectionDidChange`。

这种项目不需要引入：

- `ThemeColors`
- `ColorTheme`
- `ThemeResolver`
- `AppDesignTheme`

只使用 Appearance 能力即可。

## 4. 有颜色主题的项目

业务层自行定义：

```swift
struct AppColors {
    let background: UIColor
    let surface: UIColor
    let textPrimary: UIColor
    let textSecondary: UIColor
    let accent: UIColor
}
```

然后自行定义：

```swift
struct AppDesignTheme {
    let colors: AppColors
}
```

如果设计系统更复杂，可以继续扩展：

```swift
struct AppDesignTheme {
    let colors: AppColors
    let typography: AppTypography
    let spacing: AppSpacing
    let radius: AppRadius
}
```

基础设施无需任何修改。

## 5. 关于“反色写死”

不要在通用 `ThemePalette` 中写：

```swift
blue + dark = #64B5F6
```

应该把它放在业务自己的 `ThemeResolver` / Design Token 系统中。

如果某个模块需要特殊规则，可以：

```text
Global Appearance
      ↓
Module Resolver
      ↓
Page / Component Override
```

局部规则不会反向修改全局 Appearance。

## 6. 多人协作与颜色失控

不要让基础设施拥有：

```text
background
secondaryText
selectedTab
...
```

因为这些名称本身就是业务 Design System 的语义。

建议业务层继续演进成：

```text
Primitive Tokens
       ↓
Semantic Tokens
       ↓
Component Tokens
```

例如：

```text
Primitive: Blue500 / Blue700
      ↓
Semantic: accent / textPrimary
      ↓
Component: primaryButtonBackground
```

这样基础设施保持稳定，设计团队则可以独立治理 Token。

## 7. 从当前代码迁移

当前项目中的：

```swift
ThemeMode
ThemeAppearance
ThemeSelection
ThemeColors
AppTheme
```

建议逐步拆分：

```text
ThemeMode / ThemeAppearance
        ↓
AppearanceMode / Appearance

ThemeService 的 Appearance 部分
        ↓
AppearanceService

ThemeColors / AppTheme
        ↓
业务自己的 AppColors / AppDesignTheme

ThemeService 的广播能力
        ↓
ThemeStore<Theme>
```

不要一次性改完所有业务页面；先建立新的基础层，然后让新增模块走新 API，旧模块继续兼容。

## 8. 推荐最终依赖关系

```text
                    UIKit
                      │
                AppearanceService
                      │
               AppearanceContext
                      │
             ┌────────┴─────────┐
             │                  │
        Pure Dark Mode      ThemeResolver
             │                  │
         UIKit Colors      AppDesignTheme
                                │
                         ThemeStore<T>
                                │
                         ThemedViewController
                                │
                         Business UI
```

核心规则只有一句话：

> **基础设施负责“什么时候是 Light/Dark、谁订阅、怎么广播”；业务负责“这些状态在我的产品里具体意味着什么”。**

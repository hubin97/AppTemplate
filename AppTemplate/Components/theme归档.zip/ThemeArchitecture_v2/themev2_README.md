# Theme Architecture v2

核心原则：**Appearance 是基础状态；Theme 是 Appearance 的进一步业务封装。**

## 结构

```text
AppearanceMode
    ↓
系统 trait / 用户选择
    ↓
Appearance
    ↓
ThemeResolver
    ↓
Business Theme
    ↓
ThemeApplicable.applyTheme()
```

基础设施只提供 `Appearance`、`AppearanceMode`、`ThemeStore`、`ThemeApplicable`、`ThemeResolver`。

业务自由定义 Theme：

```swift
struct AppTheme {
    let appearance: Appearance
    let colors: AppColors
}
```

基础设施不定义任何 `ThemeColors` / `Palette` / `background` / `tabSelected` 等业务字段。

## 为什么只保留一个 ThemeApplicable？

虽然 Appearance 和 Theme 概念不同，但在真实 App 演进中，业务 Theme 通常建立在 Appearance 之上。

因此业务对象只需要：

```swift
protocol ThemeApplicable: AnyObject {
    associatedtype Theme
    func applyTheme(_ theme: Theme)
}
```

`UIViewController`、`UIView`、`UITableViewCell` 等均可直接遵循协议，不需要 Theme 基类。

## 纯 Dark Mode

项目如果只需要 Light / Dark，可以定义：

```swift
struct AppTheme {
    let appearance: Appearance
}
```

此时 Theme 只是 Appearance 的轻量封装。

## 不使用 UIKit Dynamic Colors

Dynamic Colors 只是 UIKit 的一种实现方式，不是架构要求。

业务可以显式根据 Appearance 选择静态 UIColor：

```swift
static func make(for appearance: Appearance) -> AppColors {
    switch appearance {
    case .light:
        return ...
    case .dark:
        return ...
    }
}
```

主题变化时由 `ThemeStore` 通知遵循 `ThemeApplicable` 的对象重新执行 `applyTheme`。

## 主题边界

模块是否参与主题更新由是否注册到对应 `ThemeStore` 决定。

如果已有项目级 `ViewController` 基类，可以让它统一处理 observe/remove 的生命周期；**主题能力本身仍然通过协议表达，而不是新增 ThemeViewController / ThemeView 等基类。**

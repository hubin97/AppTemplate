import UIKit

// 示例 2：Light/Dark + 业务颜色，但完全不使用 UIKit Dynamic Colors。
// AppColors 是业务层类型，不属于 Infrastructure。

struct AppColors {
    let background: UIColor
    let surface: UIColor
    let textPrimary: UIColor
    let textSecondary: UIColor
    let accent: UIColor
    let separator: UIColor

    static func make(for appearance: Appearance) -> AppColors {
        switch appearance {
        case .light:
            return AppColors(
                background: .white,
                surface: UIColor(white: 0.96, alpha: 1),
                textPrimary: .black,
                textSecondary: UIColor(white: 0.35, alpha: 1),
                accent: UIColor(red: 0.10, green: 0.45, blue: 0.82, alpha: 1),
                separator: UIColor(white: 0.85, alpha: 1)
            )

        case .dark:
            return AppColors(
                background: UIColor(white: 0.06, alpha: 1),
                surface: UIColor(white: 0.12, alpha: 1),
                textPrimary: .white,
                textSecondary: UIColor(white: 0.70, alpha: 1),
                accent: UIColor(red: 0.39, green: 0.71, blue: 0.95, alpha: 1),
                separator: UIColor(white: 0.25, alpha: 1)
            )
        }
    }
}

struct AppTheme {
    let appearance: Appearance
    let colors: AppColors

    static func make(for appearance: Appearance) -> AppTheme {
        AppTheme(
            appearance: appearance,
            colors: .make(for: appearance)
        )
    }
}

@MainActor
let appThemeStore = ThemeStore<AppTheme>(
    appearance: .light,
    resolver: { AppTheme.make(for: $0) }
)

final class ProfileView: UIView, ThemeApplicable {
    typealias Theme = AppTheme

    private let titleLabel = UILabel()

    func applyTheme(_ theme: AppTheme) {
        backgroundColor = theme.colors.surface
        titleLabel.textColor = theme.colors.textPrimary
    }
}

final class ProfileViewController: UIViewController, ThemeApplicable {
    typealias Theme = AppTheme

    private let profileView = ProfileView()

    func applyTheme(_ theme: AppTheme) {
        view.backgroundColor = theme.colors.background
        profileView.applyTheme(theme)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        appThemeStore.observe(self) { controller, theme in
            controller.applyTheme(theme)
        }
    }

    deinit {
        appThemeStore.remove(self)
    }
}

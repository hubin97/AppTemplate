import UIKit

// 示例 1：仅考虑纯 Dark Mode。
// 不定义 Color Theme，也不使用 UIKit Dynamic Colors。

struct SimpleAppTheme {
    let appearance: Appearance
}

@MainActor
let simpleThemeStore = ThemeStore<SimpleAppTheme>(
    appearance: .light,
    resolver: { SimpleAppTheme(appearance: $0) }
)

final class LoginViewController: UIViewController, ThemeApplicable {
    typealias Theme = SimpleAppTheme

    private let titleLabel = UILabel()
    private let containerView = UIView()

    func applyTheme(_ theme: SimpleAppTheme) {
        switch theme.appearance {
        case .light:
            view.backgroundColor = .white
            containerView.backgroundColor = UIColor(white: 0.95, alpha: 1)
            titleLabel.textColor = .black

        case .dark:
            view.backgroundColor = .black
            containerView.backgroundColor = UIColor(white: 0.12, alpha: 1)
            titleLabel.textColor = .white
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        simpleThemeStore.observe(self) { controller, theme in
            controller.applyTheme(theme)
        }
    }

    deinit {
        simpleThemeStore.remove(self)
    }
}

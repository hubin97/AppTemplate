import UIKit

// 可选示例：用户选择 system 时，只在一个根入口把系统 trait
// 转换成 Appearance，再更新 ThemeStore。
// 页面本身不需要分别监听 traitCollectionDidChange。

@MainActor
final class AppearanceCoordinator<Theme> {
    let mode: AppearanceMode
    let store: ThemeStore<Theme>

    init(
        mode: AppearanceMode,
        resolver: @escaping ThemeStore<Theme>.Resolver,
        initialTraits: UITraitCollection
    ) {
        self.mode = mode
        let initialAppearance = mode.resolve(using: initialTraits)
        self.store = ThemeStore(
            appearance: initialAppearance,
            resolver: resolver
        )
    }

    func traitCollectionDidChange(_ traits: UITraitCollection) {
        store.update(
            appearance: mode.resolve(using: traits)
        )
    }
}

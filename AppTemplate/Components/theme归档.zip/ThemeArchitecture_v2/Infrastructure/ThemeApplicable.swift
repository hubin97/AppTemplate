@MainActor
public protocol ThemeApplicable: AnyObject {
    associatedtype Theme
    func applyTheme(_ theme: Theme)
}

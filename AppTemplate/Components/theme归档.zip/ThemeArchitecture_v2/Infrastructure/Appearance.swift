import UIKit

public enum Appearance: Equatable {
    case light
    case dark
}

public enum AppearanceMode: Equatable {
    case system
    case light
    case dark

    @MainActor
    public func resolve(using traits: UITraitCollection) -> Appearance {
        switch self {
        case .light: return .light
        case .dark: return .dark
        case .system:
            return traits.userInterfaceStyle == .dark ? .dark : .light
        }
    }
}

@MainActor
public protocol ThemeResolver {
    associatedtype Theme
    func resolve(for appearance: Appearance) -> Theme
}

import Foundation

@MainActor
public final class ThemeStore<Theme> {
    public typealias Resolver = @MainActor (Appearance) -> Theme

    public private(set) var appearance: Appearance
    private let resolver: Resolver
    private var observers: [ObjectIdentifier: WeakObserver] = [:]

    private final class WeakObserver {
        weak var object: AnyObject?
        let apply: (AnyObject, Theme) -> Void

        init(object: AnyObject, apply: @escaping (AnyObject, Theme) -> Void) {
            self.object = object
            self.apply = apply
        }
    }

    public init(appearance: Appearance, resolver: @escaping Resolver) {
        self.appearance = appearance
        self.resolver = resolver
    }

    public var currentTheme: Theme {
        resolver(appearance)
    }

    public func update(appearance: Appearance) {
        guard self.appearance != appearance else { return }

        self.appearance = appearance
        let theme = currentTheme

        observers = observers.filter { $0.value.object != nil }

        for observer in observers.values {
            guard let object = observer.object else { continue }
            observer.apply(object, theme)
        }
    }

    public func observe<Object: AnyObject>(
        _ object: Object,
        applyImmediately: Bool = true,
        apply: @escaping @MainActor (Object, Theme) -> Void
    ) {
        observers[ObjectIdentifier(object)] = WeakObserver(
            object: object,
            apply: { object, theme in
                guard let object = object as? Object else { return }
                apply(object, theme)
            }
        )

        if applyImmediately {
            apply(object, currentTheme)
        }
    }

    public func remove<Object: AnyObject>(_ object: Object) {
        observers.removeValue(forKey: ObjectIdentifier(object))
    }
}
